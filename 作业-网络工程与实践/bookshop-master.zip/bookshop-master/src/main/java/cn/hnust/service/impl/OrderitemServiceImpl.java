package cn.hnust.service.impl;

import org.springframework.stereotype.Service;

import cn.hnust.service.OrderitemService;

@Service
public class OrderitemServiceImpl implements OrderitemService{

}
