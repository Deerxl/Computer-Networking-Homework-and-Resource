package cn.hnust.service;

public interface RoleService {

}
