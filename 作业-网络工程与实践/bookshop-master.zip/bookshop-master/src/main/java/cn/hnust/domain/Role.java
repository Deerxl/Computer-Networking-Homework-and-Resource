package cn.hnust.domain;

public class Role {
	private String id;
	private String name;
	private Integer state;
	public String getId() {
		return id;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
