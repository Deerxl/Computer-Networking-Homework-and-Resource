package cn.hnust.service.impl;

import cn.hnust.service.RoleService;

public class RoleServiceImpl implements RoleService {

}
